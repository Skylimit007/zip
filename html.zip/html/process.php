<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    // Add your email here to receive the form data
    $to = 'jameswebsolutions.org@gmail.com'; // Change this to your email

    // Subject
    $subject = 'New Contact Form Submission';

    // Message
    $email_message = "Name: ".$name."\n";
    $email_message .= "Email: ".$email."\n";
    $email_message .= "Message: \n".$message."\n";

    // Headers
    $headers = 'From: '.$email."\r\n".
    'Reply-To: '.$email."\r\n" .
    'X-Mailer: PHP/' . phpversion();

    // Sending email
    if (mail($to, $subject, $email_message, $headers)) {
        echo 'Thank you for your message. We will get back to you soon!';
    } else {
        echo 'Sorry, something went wrong. Please try again later.';
    }
} else {
    // If the form is not submitted, redirect back to the contact form page
    header("Location: contact.php");
    exit();
}
?>
