<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            background-image: url('images/background.jpg');
            background-size: cover;
            background-position: center;
        }

        .container {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            margin: 50px auto;
            width: 50%;
            text-align: center;
        }

        form {
            text-align: left;
        }

        input[type="text"], input[type="email"], textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        h2 {
            color: #333;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Contact Us</h2>
    <p><strong>Address:</strong> Nairobi, Kenya</p>
    <p><strong>Call:</strong> +254700298334</p>
    <p><strong>Call:</strong> +254115742573</p>
    <p><strong>Email:</strong> jameswebsolutions.org@gmail.com</p>

    <h2>Send us a message</h2>
    <form action="process.php" method="post">
        <input type="text" name="name" placeholder="Your Name" required><br><br>
        <input type="email" name="email" placeholder="Your Email" required><br><br>
        <textarea name="message" placeholder="Your Message" required></textarea><br><br>
        <input type="submit" value="Submit">
    </form>
</div>

</body>
</html>
