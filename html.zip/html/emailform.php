<!DOCTYPE html>
<html>
<head>
<style>
    form {
        max-width: 300px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #f2f2f2;
        border-radius: 5px;
        background-color: #f9f9f9;
    }

    input[type=email], input[type=text], textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        margin-bottom: 16px;
    }

    input[type=submit] {
        background-color: #4CAF50;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<?php
if (isset($_POST['submit'])) {
    $to = "jameswebhosting.org@gmail.com";
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $headers = "From: " . $_POST['email'];

    if (mail($to, $subject, $message, $headers)) {
        echo "Email sent successfully";
    } else {
        echo "Email sending failed";
    }
}
?>

<form method="post">
    <label for="email">Your Email:</label><br>
    <input type="email" id="email" name="email"><br><br>
    <label for="subject">Subject:</label><br>
    <input type="text" id="subject" name="subject"><br><br>
    <label for="message">Message:</label><br>
    <textarea id="message" name="message" rows="4" cols="50"></textarea><br><br>
    <input type="submit" name="submit" value="Send Email">
</form>

</body>
</html>
