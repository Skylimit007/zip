# MPesa Donate

MPesa-Donate is a Simple PHP Website that Uses Safaricom Daraja API for STK push.
View live demo [here](https://mpesa-donate.herokuapp.com/)

## Languages and Technologies 🛠
- HTML
- Bootstrap 4
- PHP
- Safaricom Daraja


> NOTE: Any amount you send on the website goes to Safaricom's sandbox PAYBILL.
