<!DOCTYPE html>
<html>
<body>

<?php
$phone_number = "+254115742573";
$whatsapp_message = "Hello, I would like to connect with you.";

echo "Phone Number: " . $phone_number . "<br>";
echo '<a href="https://wa.me/' . str_replace('+', '', $phone_number) . '?text=' . urlencode($whatsapp_message) . '">Send WhatsApp Message</a>';
?>

</body>
</html>
